#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/// LANZAR DADOS ROUND 1
int lanzarDadosR1(int v[], int cant, int tam);

/// LANZAR DADOS
void lanzarDados(int v[], int cant, int tam);

/// MOSTRAR DADOS
void mostrarDados(int v[], int cant, int tam);

///SUMAR VECTOR
int sumarV(int v[], int cant);

int guardarDados(int v[], int cant, int tam);


#endif // FUNCIONES_H_INCLUDED
